﻿CREATE TABLE [dbo].[Labels] (
    [LabelId]   INT            NOT NULL IDENTITY(1,1),
    [Label]     NVARCHAR (50)  NOT NULL,
    CONSTRAINT [PK_Labels] PRIMARY KEY CLUSTERED ([LabelId] ASC),
    CONSTRAINT [UK_Labels] UNIQUE ([Label] ASC)
);